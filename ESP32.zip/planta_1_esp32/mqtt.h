#include <ArduinoMqttClient.h>
#include <ArduinoJson.h>
#include <WiFi.h>  // Include the WiFi library based on the board (already included in most boards)
#include <time.h>  // Time library for local time retrieval

// MQTT configuration
const char* broker = "mqtt.tago.io";
int port = 1883;
const char* willTopic = "esp32";
const char* inTopic = "arduino/in";
const char* outTopic = "esp32";
const char* clientId = "csv_publisher";
const char* username = "Token #2";
const char* password = "25bb401f-3f50-4665-97d7-ab87fc4fdcea"; //device3
//const char* password = "c3770331-0ba0-4e83-8161-64581cbfd679";
//const char* password = "99b46d4a-edc6-41ec-8479-6ac89fc8159c";


// Time zone and NTP server configuration (optional)
const long gmtOffset_sec = 0;                      // -4 * 60 * 60 = -14400 (comment out if not used)
const int daylightOffset_sec = 3600;                   // comment out if not used)
const char* ntpServer = "south-america.pool.ntp.org";  // comment out if not used)

// Global variables
WiFiClient wifiClient;
MqttClient mqttClient(wifiClient);
char tempo[80];

// Function to connect to WiFi network
void connect_to_WiFi_network() {
  Serial.print("Connecting to WiFi SSID: ");
  Serial.println(ssid);
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(5000);
  }
  Serial.println("Connected to the network");
}

// Function to handle incoming MQTT messages (unchanged)
void onMqttMessage(int messageSize) {
  // ... (same logic as before)
}

// Function to connect to the MQTT broker
void connect_to_mqtt_broker() {
  mqttClient.setId(clientId);
  mqttClient.setUsernamePassword(username, password);

  String willPayload = "oh no!";
  bool willRetain = true;
  int willQos = 1;

  mqttClient.beginWill(willTopic, willPayload.length(), willRetain, willQos);
  mqttClient.print(willPayload);
  mqttClient.endWill();

  Serial.print("Connecting to MQTT broker: ");
  Serial.println(broker);

  if (!mqttClient.connect(broker, port)) {
    Serial.print("MQTT connection failed! Error code = ");
    Serial.println(mqttClient.connectError());
    while (1)
      ;
  }
  Serial.println("Connected to the MQTT broker!");
  //mqttClient.onMessage(onMqttMessage);
  //Serial.print("Subscribing to topic: ");
  //Serial.println(inTopic);
  //mqttClient.subscribe(inTopic, 1);  // Subscribe with QoS 1
  //Serial.print("Waiting for messages on topic: ");
  //Serial.println(inTopic);
}

void now(){
  time_t timeinfo;
  time(&timeinfo);
  struct tm *time_now = localtime(&timeinfo);
  if (!time_now) { //getLocalTime(
    Serial.println("Failed to get local time");
    return;
  }
  strftime(tempo, 80, "%Y-%m-%d %H:%M:%S", time_now);  // Format time string
}
  


// Function to serialize data into a JSON object and publish to MQTT
void mqtt_send_Message(const char* topic, const char* variable, float value, const char* unit) {
  DynamicJsonDocument payload(128);
  payload["variable"] = variable;
  payload["value"] = value;

  /*time_t timeinfo;
  time(&timeinfo);
  struct tm *now = localtime(&timeinfo);
  if (!now) { //getLocalTime(
    Serial.println("Failed to get local time");
    return;
  }

  strftime(tempo, 80, "%Y-%m-%d %H:%M:%S", now);  // Format time string
  */
  payload["time"] = tempo;
  payload["unit"] = unit;
  char buffer[256];
  size_t n = serializeJson(payload, buffer, sizeof(buffer));

  bool retained = false;
  int qos = 1;
  bool dup = false;

  mqttClient.beginMessage(topic, n, retained, qos, dup);
  mqttClient.print(buffer);
  mqttClient.endMessage();
}
