#include <OneWire.h>
#include <DallasTemperature.h>

// Pin definitions
const int ONE_WIRE_BUS = 23;
const int TEMPERATURE_PRECISION = 12;
const int pin_pwm = 15;

// Communication constants
const int HANDSHAKE = 0;
const int DATA_REQUEST = 1;
const int ON_REQUEST = 2;
const int STREAM = 3;
const int SET_PWM = 4;

// Global variables
int dutyCycle = 255;

// OneWire and DallasTemperature instances
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
DeviceAddress mos_Thermometer, amb_Thermometer;

// Function prototypes
void init_sensors();
void printAddress(DeviceAddress deviceAddress);
void printResolution(DeviceAddress deviceAddress);
float get_temp(DeviceAddress deviceAddress);
void printData();

void init_sensors(void) {
  pinMode(LED_BUILTIN, OUTPUT);  // Use LED_BUILTIN for consistency

  // Start up the library
  sensors.begin();

  // Search for devices on the bus and assign addresses
  Serial.print("Locating devices...");
  int devicesFound = sensors.getDeviceCount();
  Serial.print("Found ");
  Serial.print(devicesFound, DEC);
  Serial.println(" devices.");

  // Report parasite power requirements
  Serial.print("Parasite power is: ");
  if (sensors.isParasitePowerMode()) {
    Serial.println("ON");
  } else {
    Serial.println("OFF");
  }

  if (devicesFound < 2) {
    Serial.println("Error: Expected at least 2 devices!");
    return;  // Exit function if not enough devices found
  }

  // Assign addresses based on index (assuming order consistency)
  if (!sensors.getAddress(amb_Thermometer, 0)) {
    Serial.println("Unable to find address for Device 0");
  }
  if (!sensors.getAddress(mos_Thermometer, 1)) {
    Serial.println("Unable to find address for Device 1");
  }

  // Set temperature resolution for both devices
  sensors.setResolution(mos_Thermometer, TEMPERATURE_PRECISION);
  sensors.setResolution(amb_Thermometer, TEMPERATURE_PRECISION);

  Serial.println("Sensor initialization complete.");
}

// function to print a device address
void printAddress(DeviceAddress deviceAddress) {
  for (uint8_t i = 0; i < 8; i++) {
    Serial.print("%02x");
    Serial.print(deviceAddress[i], HEX);
  }
}

// function to print a device's resolution
void printResolution(DeviceAddress deviceAddress) {
  Serial.print("Resolution: ");
  Serial.print(sensors.getResolution(deviceAddress));
  Serial.println();
}


//Funções

float get_temp(DeviceAddress deviceAddress) {
  sensors.requestTemperatures();  // Request temperature readings
  delay(1);                       // Wait for readings (might be adjustable based on sensor)
  float tempC = sensors.getTempC(deviceAddress);
  if (tempC == DEVICE_DISCONNECTED_C) {
    Serial.println("Error: Could not read temperature data");
    return NAN;  // Return Not a Number on error
  }
  return tempC;
}

// function to print the temperature for a device
float get_temps() {
  return get_temp(amb_Thermometer), get_temp(mos_Thermometer);
}
