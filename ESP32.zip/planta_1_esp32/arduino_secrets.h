#define SECRET_SSID ""
#define SECRET_PASS ""

// Network credentials
char ssid[] = SECRET_SSID;
char pass[] = SECRET_PASS;